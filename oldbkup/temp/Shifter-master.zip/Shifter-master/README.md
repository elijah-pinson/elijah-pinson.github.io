<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Shifter 

A jQuery plugin for simple slide-out mobile navigation. Part of the Formstone Library. 

- [Demo](http://formstone.it/components/Shifter/demo/index.html) 
- [Documentation](http://formstone.it/shifter/) 

#### Bower Support 
`bower install Shifter`